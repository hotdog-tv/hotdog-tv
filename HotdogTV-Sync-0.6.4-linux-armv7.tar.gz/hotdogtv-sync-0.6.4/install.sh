#!/bin/sh
# Installs Hotdog TV Sync as a service, or updates the one installed — run it again from a newer
# copy. Run as root, from the folder it was unpacked into:
#   sudo ./install.sh
# The program goes in /opt/hotdogtv-sync, its data in /var/lib/hotdogtv-sync (an update never
# touches the data), and it runs as its own account, hotdogtv-sync, started with the computer.
# Beside it goes the updater (hotdogtv-sync-update.service and .path), which runs this script
# from a newer copy when the owner presses Update now in the portal — with HOTDOG_UPDATING=1.
set -eu

here=$(cd "$(dirname "$0")" && pwd)
prefix=/opt/hotdogtv-sync
data=/var/lib/hotdogtv-sync
units=/etc/systemd/system
unit=$units/hotdogtv-sync.service
account=hotdogtv-sync
updating_itself=${HOTDOG_UPDATING:-}

if [ "$(id -u)" -ne 0 ]; then
    echo "Run it as root: sudo $0" >&2
    exit 1
fi
if ! command -v systemctl >/dev/null 2>&1 || [ ! -d /run/systemd/system ]; then
    echo "This computer doesn't use systemd. Run the program by hand instead:" >&2
    echo "  $here/hotdogtv-sync -data <folder for its data>" >&2
    exit 1
fi
if [ ! -x "$here/hotdogtv-sync" ]; then
    echo "hotdogtv-sync isn't beside this script — unpack the whole archive and run it from there." >&2
    exit 1
fi
if ! "$here/hotdogtv-sync" -h >/dev/null 2>&1; then
    echo "This copy of hotdogtv-sync doesn't run on this computer ($(uname -m)) — is it the right download?" >&2
    exit 1
fi

if ! id "$account" >/dev/null 2>&1; then
    nologin=$(command -v nologin || echo /bin/false)
    useradd --system --user-group --home-dir "$data" --no-create-home --shell "$nologin" "$account"
    echo "Made the account $account."
fi

updating=no
if systemctl is-active --quiet hotdogtv-sync; then
    updating=yes
    systemctl stop hotdogtv-sync
fi

install -d -m 0755 "$prefix"
install -m 0755 "$here/hotdogtv-sync" "$prefix/hotdogtv-sync.new"
mv -f "$prefix/hotdogtv-sync.new" "$prefix/hotdogtv-sync"
install -m 0644 "$here/hotdogtv-sync.service" "$unit"
install -m 0644 "$here/hotdogtv-sync-update.service" "$units/hotdogtv-sync-update.service"
install -m 0644 "$here/hotdogtv-sync-update.path" "$units/hotdogtv-sync-update.path"
install -d -m 0700 -o "$account" -g "$account" "$data"

# The firewall's names for its port (8920/tcp): ufw's app profile and firewalld's service, put in
# place at every install so the commands that use them work. They are only switched on (below)
# at a fresh install, so a port an admin has since closed isn't opened again by an update.
if [ -d /etc/ufw/applications.d ]; then
    install -m 0644 "$here/hotdogtv-sync.ufw" /etc/ufw/applications.d/hotdogtv-sync
fi
if [ -d /etc/firewalld ]; then
    install -d -m 0755 /etc/firewalld/services
    install -m 0644 "$here/hotdogtv-sync.firewalld.xml" /etc/firewalld/services/hotdogtv-sync.xml
fi

systemctl daemon-reload
systemctl enable --quiet hotdogtv-sync
systemctl start hotdogtv-sync
systemctl enable --quiet --now hotdogtv-sync-update.path

version=$("$prefix/hotdogtv-sync" -version 2>/dev/null || true)
if [ -n "$updating_itself" ]; then
    echo "Updated by the updater and started again${version:+ ($version)}."
    exit 0
fi

if [ "$updating" = yes ]; then
    echo "Updated and started again${version:+ ($version)}."
else
    echo "Installed and started${version:+ ($version)}; it starts with the computer from now on."
fi

# A fresh install opens the port in the firewall that is on (firewalld is on by default on Fedora,
# RHEL and the like; ufw on Ubuntu only if it was turned on). HOTDOG_NO_FIREWALL=1 leaves it be.
firewall_note="If a firewall is on, let devices reach port 8920/tcp (e.g. sudo ufw allow 8920/tcp)."
if [ "$updating" = no ] && [ -z "${HOTDOG_NO_FIREWALL:-}" ]; then
    if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
        firewall-cmd --reload >/dev/null 2>&1 || true   # (so it knows the new service)
        if firewall-cmd --permanent --add-service=hotdogtv-sync >/dev/null 2>&1 && firewall-cmd --reload >/dev/null 2>&1; then
            firewall_note="firewalld is on: port 8920/tcp has been opened in its default zone (service hotdogtv-sync).
To close it again: sudo firewall-cmd --permanent --remove-service=hotdogtv-sync && sudo firewall-cmd --reload"
        else
            firewall_note="firewalld is on, and port 8920/tcp couldn't be opened in it. Open it: sudo firewall-cmd --permanent --add-port=8920/tcp && sudo firewall-cmd --reload"
        fi
    elif command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
        if ufw allow "Hotdog TV Sync" >/dev/null 2>&1 || ufw allow 8920/tcp >/dev/null 2>&1; then
            firewall_note="ufw is on: port 8920/tcp has been allowed (\"Hotdog TV Sync\"). To close it again: sudo ufw delete allow \"Hotdog TV Sync\""
        else
            firewall_note="ufw is on, and port 8920/tcp couldn't be allowed in it. Allow it: sudo ufw allow 8920/tcp"
        fi
    fi
fi

# At the first start there is no admin yet: the setup link is in what the server said.
sleep 2
setup=$(journalctl -u hotdogtv-sync -b --no-pager -o cat 2>/dev/null | grep '#setup=' | tail -n 3 || true)
if [ -n "$setup" ]; then
    echo
    echo "Finish setting it up in a browser — open one of these (the code in it works until setup is done,"
    echo "or until the server is restarted, which makes a new one):"
    echo "$setup" | sed 's/^\[sync\] *//'
else
    port=8920
    echo "The portal: http://$(hostname -I 2>/dev/null | cut -d' ' -f1 || echo localhost):$port/ (or the port set in it)"
fi
echo
echo "Its data: $data   What it says: journalctl -u hotdogtv-sync -e"
echo "$firewall_note"
echo "Can't connect from another device? Check what's in the way: $prefix/hotdogtv-sync -check"
