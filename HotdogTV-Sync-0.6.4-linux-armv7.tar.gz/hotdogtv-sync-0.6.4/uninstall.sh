#!/bin/sh
# Removes the Hotdog TV Sync service and program. Its data (/var/lib/hotdogtv-sync: everyone's
# accounts, synced data and devices' backups) is left where it is unless asked for:
#   sudo ./uninstall.sh
#   sudo ./uninstall.sh --delete-data
set -eu

if [ "$(id -u)" -ne 0 ]; then
    echo "Run it as root: sudo $0" >&2
    exit 1
fi

if command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now --quiet hotdogtv-sync-update.path 2>/dev/null || true
    systemctl disable --now --quiet hotdogtv-sync 2>/dev/null || true
    rm -f /etc/systemd/system/hotdogtv-sync.service /etc/systemd/system/hotdogtv-sync-update.service \
        /etc/systemd/system/hotdogtv-sync-update.path
    systemctl daemon-reload
fi
rm -rf /opt/hotdogtv-sync
echo "The service and program are removed."

# The firewall's opening for it (install.sh), and the names it was made under.
if [ -f /etc/firewalld/services/hotdogtv-sync.xml ]; then
    if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
        firewall-cmd --permanent --remove-service=hotdogtv-sync >/dev/null 2>&1 || true
    fi
    rm -f /etc/firewalld/services/hotdogtv-sync.xml
    firewall-cmd --reload >/dev/null 2>&1 || true
    echo "Its firewalld service is removed."
fi
if [ -f /etc/ufw/applications.d/hotdogtv-sync ]; then
    if command -v ufw >/dev/null 2>&1; then
        ufw delete allow "Hotdog TV Sync" >/dev/null 2>&1 || true
    fi
    rm -f /etc/ufw/applications.d/hotdogtv-sync
    echo "Its ufw profile is removed."
fi

if [ "${1:-}" = "--delete-data" ]; then
    rm -rf /var/lib/hotdogtv-sync
    userdel hotdogtv-sync 2>/dev/null || true
    echo "Its data and account are removed too."
else
    echo "Its data is still in /var/lib/hotdogtv-sync (run with --delete-data to remove it, and the account)."
fi
