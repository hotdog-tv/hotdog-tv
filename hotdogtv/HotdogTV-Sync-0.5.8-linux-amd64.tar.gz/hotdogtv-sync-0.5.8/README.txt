Hotdog TV Sync for Linux
========================

The sync server the Hotdog TV apps pair with, as one program file. Any 64-bit Linux (x86-64 or
ARM, e.g. a Raspberry Pi 4/5 with a 64-bit OS) or a 32-bit ARM one (armv7); nothing else to install.

As a service (systemd — Debian, Ubuntu, Raspberry Pi OS, Fedora, ...)
    tar xzf HotdogTV-Sync-<version>-linux-<arch>.tar.gz
    cd hotdogtv-sync-<version>
    sudo ./install.sh

  It starts now and with the computer, as its own account (hotdogtv-sync), with its data in
  /var/lib/hotdogtv-sync. At the first start it prints a setup link: open it in a browser on any
  computer on the network to make the admin login. Lost it? It is in
      journalctl -u hotdogtv-sync | grep setup=
  (restarting the server makes a new code).

  Updating: the server looks for a newer version twice a day and says so in the portal (Admin ›
  Server); Update now puts it in place, and the server is back a few seconds later. That is done
  by a second service, hotdogtv-sync-update, which runs as root only when asked: it fetches the
  newer version from the download site itself and checks it is the one published before
  installing it (what it did: journalctl -u hotdogtv-sync-update). Or by hand: unpack the newer
  version and run its install.sh. Either way the data is left as it is. (Versions before 0.5.7
  don't update themselves: install 0.5.7 or later by hand once.)

  Removing: sudo ./uninstall.sh (keeps the data), or sudo ./uninstall.sh --delete-data.

By hand
    ./hotdogtv-sync                      data in ~/.config/Hotdog TV Sync
    ./hotdogtv-sync -data /some/folder   data there
    ./hotdogtv-sync -h                   every option (port, backups, moving the key, ...)

Devices reach it on port 8920 (TCP); if a firewall is on, open it, e.g. sudo ufw allow 8920/tcp.

The key
  The database's secrets (providers' logins, sync codes, two-step sign-in) are sealed with a key
  in hotdogtv-sync.key beside it. On Linux that file is protected by its permissions alone (only
  the server's account can read it) — not encrypted by the system as it is on Windows — so a
  copy of the whole data folder, key included, can be read: if you copy the folder anywhere,
  keep that copy safe. The portal's backups (Admin › Backups of this server) leave the key out:
  without a password one restores only on this server, while its key is here; give them a
  password and they restore anywhere, with it.

Moving from a Windows server
  On Windows:  "Hotdog TV Sync.exe" -export-key key.txt     (the key can't be read off Windows otherwise)
  Copy %APPDATA%\Hotdog TV Sync\hotdogtv-sync.db and key.txt across, then on Linux, with the
  service stopped (sudo systemctl stop hotdogtv-sync):
      sudo install -o hotdogtv-sync -g hotdogtv-sync -m 600 hotdogtv-sync.db /var/lib/hotdogtv-sync/
      sudo -u hotdogtv-sync /opt/hotdogtv-sync/hotdogtv-sync -data /var/lib/hotdogtv-sync -import-key key.txt
      sudo systemctl start hotdogtv-sync
  and destroy key.txt. Or: make a backup with a password in the Windows portal and restore it
  from the setup page of the new server.
