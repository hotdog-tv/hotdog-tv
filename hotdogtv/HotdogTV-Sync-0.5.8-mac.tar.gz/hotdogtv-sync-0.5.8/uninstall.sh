#!/bin/sh
# Removes the Hotdog TV Sync service and program from a Mac. Its data (everyone's accounts, synced
# data and devices' backups, in ~/Library/Application Support/Hotdog TV Sync) is left where it is.
#   sudo sh uninstall.sh
set -eu

label=xyz.auiptv.hotdogtv-sync
if [ "$(id -u)" -ne 0 ]; then
    echo "Run it with sudo: sudo sh $0" >&2
    exit 1
fi
launchctl bootout "system/$label-update" 2>/dev/null || true
launchctl bootout "system/$label" 2>/dev/null || true
rm -f "/Library/LaunchDaemons/$label.plist" "/Library/LaunchDaemons/$label-update.plist"
rm -rf /usr/local/hotdogtv-sync
echo "The service and program are removed. Its data is still in ~/Library/Application Support/Hotdog TV Sync."
