#!/bin/sh
# Installs Hotdog TV Sync as a service, or updates the one installed — run it again from a newer
# copy. Run as root, from the folder it was unpacked into:
#   sudo ./install.sh
# The program goes in /opt/hotdogtv-sync, its data in /var/lib/hotdogtv-sync (an update never
# touches the data), and it runs as its own account, hotdogtv-sync, started with the computer.
set -eu

here=$(cd "$(dirname "$0")" && pwd)
prefix=/opt/hotdogtv-sync
data=/var/lib/hotdogtv-sync
unit=/etc/systemd/system/hotdogtv-sync.service
account=hotdogtv-sync

if [ "$(id -u)" -ne 0 ]; then
    echo "Run it as root: sudo $0" >&2
    exit 1
fi
if ! command -v systemctl >/dev/null 2>&1 || [ ! -d /run/systemd/system ]; then
    echo "This computer doesn't use systemd. Run the program by hand instead:" >&2
    echo "  $here/hotdogtv-sync -data <folder for its data>" >&2
    exit 1
fi
if [ ! -x "$here/hotdogtv-sync" ]; then
    echo "hotdogtv-sync isn't beside this script — unpack the whole archive and run it from there." >&2
    exit 1
fi
if ! "$here/hotdogtv-sync" -h >/dev/null 2>&1; then
    echo "This copy of hotdogtv-sync doesn't run on this computer ($(uname -m)) — is it the right download?" >&2
    exit 1
fi

if ! id "$account" >/dev/null 2>&1; then
    nologin=$(command -v nologin || echo /bin/false)
    useradd --system --user-group --home-dir "$data" --no-create-home --shell "$nologin" "$account"
    echo "Made the account $account."
fi

updating=no
if systemctl is-active --quiet hotdogtv-sync; then
    updating=yes
    systemctl stop hotdogtv-sync
fi

install -d -m 0755 "$prefix"
install -m 0755 "$here/hotdogtv-sync" "$prefix/hotdogtv-sync.new"
mv -f "$prefix/hotdogtv-sync.new" "$prefix/hotdogtv-sync"
install -m 0644 "$here/hotdogtv-sync.service" "$unit"
install -d -m 0700 -o "$account" -g "$account" "$data"

systemctl daemon-reload
systemctl enable --quiet hotdogtv-sync
systemctl start hotdogtv-sync

version=$("$prefix/hotdogtv-sync" -version 2>/dev/null || true)
if [ "$updating" = yes ]; then
    echo "Updated and started again${version:+ ($version)}."
else
    echo "Installed and started${version:+ ($version)}; it starts with the computer from now on."
fi

# At the first start there is no admin yet: the setup link is in what the server said.
sleep 2
setup=$(journalctl -u hotdogtv-sync -b --no-pager -o cat 2>/dev/null | grep '#setup=' | tail -n 3 || true)
if [ -n "$setup" ]; then
    echo
    echo "Finish setting it up in a browser — open one of these (the code in it works until setup is done,"
    echo "or until the server is restarted, which makes a new one):"
    echo "$setup" | sed 's/^\[sync\] *//'
else
    port=8920
    echo "The portal: http://$(hostname -I 2>/dev/null | cut -d' ' -f1 || echo localhost):$port/ (or the port set in it)"
fi
echo
echo "Its data: $data   What it says: journalctl -u hotdogtv-sync -e"
echo "If a firewall is on, let devices reach port 8920/tcp (e.g. sudo ufw allow 8920/tcp)."
