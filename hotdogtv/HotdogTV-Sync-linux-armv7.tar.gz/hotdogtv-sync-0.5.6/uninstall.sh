#!/bin/sh
# Removes the Hotdog TV Sync service and program. Its data (/var/lib/hotdogtv-sync: everyone's
# accounts, synced data and devices' backups) is left where it is unless asked for:
#   sudo ./uninstall.sh
#   sudo ./uninstall.sh --delete-data
set -eu

if [ "$(id -u)" -ne 0 ]; then
    echo "Run it as root: sudo $0" >&2
    exit 1
fi

if command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now --quiet hotdogtv-sync 2>/dev/null || true
    rm -f /etc/systemd/system/hotdogtv-sync.service
    systemctl daemon-reload
fi
rm -rf /opt/hotdogtv-sync
echo "The service and program are removed."

if [ "${1:-}" = "--delete-data" ]; then
    rm -rf /var/lib/hotdogtv-sync
    userdel hotdogtv-sync 2>/dev/null || true
    echo "Its data and account are removed too."
else
    echo "Its data is still in /var/lib/hotdogtv-sync (run with --delete-data to remove it, and the account)."
fi
