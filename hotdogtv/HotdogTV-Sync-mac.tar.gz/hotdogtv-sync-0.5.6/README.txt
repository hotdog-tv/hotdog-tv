Hotdog TV Sync for Mac
======================

The sync server the Hotdog TV apps pair with, as one program file — for Apple Silicon and Intel
Macs alike (both programs are in this folder; the installer picks the right one). Nothing else to
install.

As a service (starts with the Mac, before anyone signs in)
    Unpack the download (double-click it), then in Terminal:
    cd ~/Downloads/hotdogtv-sync-<version>
    sudo sh install.sh

  It runs as you, with its data in ~/Library/Application Support/Hotdog TV Sync. At the first
  start it prints a setup link: open it in a browser on any computer on the network to make the
  admin login. Lost it? It is in
      ~/Library/Application Support/Hotdog TV Sync/hotdogtv-sync-console.log
  (restarting the server makes a new code).

  Keep the Mac from sleeping (System Settings › Energy) — devices can't reach a sleeping Mac.

  Updating: unpack the newer version and run its install.sh — the data is left as it is. This
  version doesn't update itself the way the Windows one does.

  Removing: sudo sh /usr/local/hotdogtv-sync/uninstall.sh (keeps the data).

By hand
    ./hotdogtv-sync-arm64      (Apple Silicon)   or   ./hotdogtv-sync-x86_64   (Intel)
    -data /some/folder   keeps the data there (otherwise ~/Library/Application Support/Hotdog TV Sync)
    -h                   every option (port, backups, moving the key, ...)
  macOS stops a downloaded program from no known developer: install.sh clears that for the copy it
  installs; to run one of these by hand first, xattr -c hotdogtv-sync-*

Devices reach it on port 8920 (TCP). If the macOS firewall is on, allow incoming connections for
hotdogtv-sync when it asks (System Settings › Network › Firewall › Options).

The key
  The database's secrets (providers' logins, sync codes, two-step sign-in) are sealed with a key
  in hotdogtv-sync.key beside it. On a Mac that file is protected by its permissions alone (only
  your account can read it) — not encrypted by the system as it is on Windows — so a copy of the
  whole data folder, key included, can be read: if you copy the folder anywhere, keep that copy
  safe. The portal's backups (Admin › Backups of this server) leave the key out: without a
  password one restores only on this server, while its key is here; give them a password and they
  restore anywhere, with it.

Moving from a Windows server
  Make a backup with a password in the Windows portal and restore it from the setup page of the
  new server. Or copy the database across with its key: on Windows,
  "Hotdog TV Sync.exe" -export-key key.txt, then with the service stopped
  (sudo launchctl bootout system/xyz.auiptv.hotdogtv-sync) put hotdogtv-sync.db in the data
  folder, run /usr/local/hotdogtv-sync/hotdogtv-sync -data "<data folder>" -import-key key.txt,
  start it again with sudo sh install.sh, and destroy key.txt.
