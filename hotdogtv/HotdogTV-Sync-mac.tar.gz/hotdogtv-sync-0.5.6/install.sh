#!/bin/sh
# Installs Hotdog TV Sync as a service on a Mac, or updates the one installed — run it again from
# a newer copy. From the folder it was unpacked into:
#   sudo sh install.sh
# The program goes in /usr/local/hotdogtv-sync, and it runs as you (the account that ran sudo),
# started with the computer — before anyone signs in — by launchd. Its data stays in your
# ~/Library/Application Support/Hotdog TV Sync, where running it by hand keeps it too; an update
# never touches it.
set -eu

here=$(cd "$(dirname "$0")" && pwd)
prefix=/usr/local/hotdogtv-sync
label=xyz.auiptv.hotdogtv-sync
plist=/Library/LaunchDaemons/$label.plist

if [ "$(id -u)" -ne 0 ]; then
    echo "Run it with sudo: sudo sh $0" >&2
    exit 1
fi
user=${SUDO_USER:-}
if [ -z "$user" ] || [ "$user" = root ]; then
    echo "Run it with sudo from your own account (not as root), so it runs as you: sudo sh $0" >&2
    exit 1
fi
home=$(dscl . -read "/Users/$user" NFSHomeDirectory | sed 's/^NFSHomeDirectory: //')
group=$(id -gn "$user")

case "$(uname -m)" in
    arm64) program="$here/hotdogtv-sync-arm64" ;;
    x86_64) program="$here/hotdogtv-sync-x86_64" ;;
    *) echo "This Mac ($(uname -m)) isn't one it was built for." >&2; exit 1 ;;
esac
if [ ! -f "$program" ]; then
    echo "$(basename "$program") isn't beside this script — unpack the whole archive and run it from there." >&2
    exit 1
fi

data="$home/Library/Application Support/Hotdog TV Sync"
console="$data/hotdogtv-sync-console.log"

updating=no
if launchctl print "system/$label" >/dev/null 2>&1; then
    updating=yes
    launchctl bootout "system/$label" 2>/dev/null || true
fi

install -d -m 0755 "$prefix"
install -m 0755 "$program" "$prefix/hotdogtv-sync.new"
# Downloaded in a browser, it is marked as from the internet, and macOS won't start a program
# from no known developer that is
xattr -c "$prefix/hotdogtv-sync.new" 2>/dev/null || true
mv -f "$prefix/hotdogtv-sync.new" "$prefix/hotdogtv-sync"
install -m 0644 "$here/uninstall.sh" "$prefix/uninstall.sh"
sudo -u "$user" mkdir -p "$data"
chmod 700 "$data"
: > "$console"
chown "$user:$group" "$console"

cat > "$plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>$label</string>
    <key>ProgramArguments</key>
    <array>
        <string>$prefix/hotdogtv-sync</string>
        <string>-data</string>
        <string>$data</string>
    </array>
    <key>UserName</key><string>$user</string>
    <key>GroupName</key><string>$group</string>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>ThrottleInterval</key><integer>5</integer>
    <key>Umask</key><integer>63</integer>
    <key>StandardOutPath</key><string>$console</string>
    <key>StandardErrorPath</key><string>$console</string>
</dict>
</plist>
EOF
chmod 644 "$plist"
launchctl bootstrap system "$plist"

version=$("$prefix/hotdogtv-sync" -version 2>/dev/null || true)
if [ "$updating" = yes ]; then
    echo "Updated and started again${version:+ ($version)}."
else
    echo "Installed and started${version:+ ($version)}; it starts with the Mac from now on."
fi

# At the first start there is no admin yet: the setup link is in what the server said.
sleep 3
setup=$(grep '#setup=' "$console" 2>/dev/null | tail -n 3 || true)
if [ -n "$setup" ]; then
    echo
    echo "Finish setting it up in a browser — open one of these (the code in it works until setup is done,"
    echo "or until the server is restarted, which makes a new one):"
    echo "$setup" | sed 's/^\[sync\] *//'
else
    ip=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo localhost)
    echo "The portal: http://$ip:8920/ (or the port set in it)"
fi
echo
echo "Its data: $data"
echo "What it says: $console (and hotdogtv-sync.log beside it)"
echo "Keep the Mac from sleeping (System Settings › Energy), or devices can't reach it while it sleeps."
